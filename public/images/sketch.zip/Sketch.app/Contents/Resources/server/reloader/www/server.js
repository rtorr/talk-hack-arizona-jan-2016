// This file is sent to every client. It build up the websocket connection

(function() {

DEBUG = true;

var COMMANDS = {
	eval: function(data) {
		window.eval(data.script);
	},
}

var socketUrl = "ws://" + window.location.host + "/_server/ws";
var socket = new ReconnectingWebSocket(socketUrl);

socket.onmessage = function(event) {
	
	console.log("socket.onmessage", event);

	data = JSON.parse(event.data);
	
	if (data.hasOwnProperty("command") && COMMANDS.hasOwnProperty(data["command"])) {
		COMMANDS[data["command"]](data);
	}
};


// Utilities

// Taken from https://github.com/joewalnes/reconnecting-websocket/

function ReconnectingWebSocket(url, protocols) {
	protocols = protocols || [];

	// These can be altered by calling code.
	this.debug = false;
	this.reconnectInterval = 5000;
	this.reconnectDecay = 1.0;
	this.reconnectAttempts = 0;
	this.timeoutInterval = 2000;

	var self = this;
	var ws;
	var forcedClose = false;
	var timedOut = false;
	
	this.url = url;
	this.protocols = protocols;
	this.readyState = WebSocket.CONNECTING;
	this.URL = url; // Public API

	this.onopen = function(event) {};
	this.onclose = function(event) {};
	this.onconnecting = function(event) {};
	this.onmessage = function(event) {};
	this.onerror = function(event) {};

	function connect(reconnectAttempt) {
		ws = new WebSocket(url, protocols);
		
		if(!reconnectAttempt)
			self.onconnecting();
			
		if (self.debug || ReconnectingWebSocket.debugAll) {
			console.debug('ReconnectingWebSocket', 'attempt-connect', url);
		}
		
		var localWs = ws;
		var timeout = setTimeout(function() {
			if (self.debug || ReconnectingWebSocket.debugAll) {
				console.debug('ReconnectingWebSocket', 'connection-timeout', url);
			}
			timedOut = true;
			localWs.close();
			timedOut = false;
		}, self.timeoutInterval);
		
		ws.onopen = function(event) {
			clearTimeout(timeout);
			if (self.debug || ReconnectingWebSocket.debugAll) {
				console.debug('ReconnectingWebSocket', 'onopen', url);
			}
			self.readyState = WebSocket.OPEN;
			reconnectAttempt = false;
			self.reconnectAttempts = 0;
			self.onopen(event);
		};
		
		ws.onclose = function(event) {
			clearTimeout(timeout);
			ws = null;
			if (forcedClose) {
				self.readyState = WebSocket.CLOSED;
				self.onclose(event);
			} else {
				self.readyState = WebSocket.CONNECTING;
				self.onconnecting();
				if (!reconnectAttempt && !timedOut) {
					if (self.debug || ReconnectingWebSocket.debugAll) {
						console.debug('ReconnectingWebSocket', 'onclose', url);
					}
					self.onclose(event);
				}
				setTimeout(function() {
					self.reconnectAttempts++;
					connect(true);
				}, self.reconnectInterval * Math.pow(self.reconnectDecay, self.reconnectAttempts));
			}
		};
		ws.onmessage = function(event) {
			if (self.debug || ReconnectingWebSocket.debugAll) {
				console.debug('ReconnectingWebSocket', 'onmessage', url, event.data);
			}
			self.onmessage(event);
		};
		ws.onerror = function(event) {
			if (self.debug || ReconnectingWebSocket.debugAll) {
				console.debug('ReconnectingWebSocket', 'onerror', url, event);
			}
			self.onerror(event);
		};
	}
	connect(false);

	this.send = function(data) {
		if (ws) {
			if (self.debug || ReconnectingWebSocket.debugAll) {
				console.debug('ReconnectingWebSocket', 'send', url, data);
			}
			return ws.send(data);
		} else {
			throw 'INVALID_STATE_ERR : Pausing to reconnect websocket';
		}
	};

	this.close = function() {
		forcedClose = true;
		if (ws) {
			ws.close();
		}
	};

	/**
	 * Additional public API method to refresh the connection if still open (close, re-open).
	 * For example, if the app suspects bad data / missed heart beats, it can try to refresh.
	 */
	this.refresh = function() {
		if (ws) {
			ws.close();
		}
	};
}

ReconnectingWebSocket.debugAll = DEBUG;

})()