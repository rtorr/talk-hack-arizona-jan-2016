+ Add security (localhost only)
- Only refresh saved project
- Cleanup function for server / release port
- Deal with non unique handles (Unnamed1,2,3)
- Nice error handling for non existing sites


+ Refresh on save or keystroke? (only save)
+ Serve up untitled documents? (no, save panel)