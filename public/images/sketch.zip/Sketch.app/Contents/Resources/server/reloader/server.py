import os
import sys
import logging
import mimetypes
import json
import re
import itertools
import threading
import time
import socket
import traceback
import subprocess
import sys
import Queue
import netifaces
import string
import random

logger = logging.getLogger(__name__)

import tornado.httpserver
import tornado.websocket
import tornado.websocket
import tornado.template
import tornado.ioloop
import tornado.web


from tornado.escape import json_encode, json_decode

HTTPError = tornado.web.HTTPError

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, DirModifiedEvent

if not "FSEventsObserver" in str(Observer):
	print "Could not use fsevents, using %s" % Observer

def get_local_ip_address():
	for inderface_name in netifaces.interfaces():
		for ifaddress in netifaces.ifaddresses(inderface_name).setdefault(netifaces.AF_INET, [{"addr": None}]):
			addr = ifaddress.get("addr")
			if addr and addr != "127.0.0.1":
				return addr
	return "127.0.0.1"

def get_host_name():
	try:
		return socket.gethostname()
	except socket.error:
		return "127.0.0.1"

def random_string(length):
  return u''.join(random.choice(string.ascii_uppercase + string.digits) for x in range(length))

class WebSocketHandler(tornado.websocket.WebSocketHandler):
	
	def open(self):
		if self not in self.application._socket_handlers:
			self.application._socket_handlers.append(self)

	def on_close(self):
		if self in self.application._socket_handlers:
			self.application._socket_handlers.remove(self)

	def on_message(self, msg):
		pass

class StaticFileHandler(tornado.web.StaticFileHandler):

	@classmethod
	def get_append(cls, abspath):
		
		mime_type, encoding = mimetypes.guess_type(abspath)

		if mime_type == "text/html":
			return "\n<script src=\"/_server/server.js\"></script>"
		
		return ""

	@classmethod
	def get_content(cls, abspath, start=None, end=None):
		data = super(StaticFileHandler, cls).get_content(abspath, start=start, end=end)
		return itertools.chain(data, [cls.get_append(abspath)])

	def get_content_size(self):
		return super(StaticFileHandler, self).get_content_size() + len(self.get_append(self.absolute_path))

	def is_text_content(self):

		mime_type = self.get_content_type()

		if mime_type and "text" in self.get_content_type():
			return True

		return False

	def set_extra_headers(self, path):
		
		if self.is_text_content():
			self.set_header("Cache-control", "no-cache")

	def get_content_type(self):

		root, ext = os.path.splitext(self.absolute_path)
		extra_content_types = {
			'.svg'    : 'image/svg+xml',
			'.html'   : 'text/html',
			'.css'    : 'text/css',
			'.png'    : 'image/png',
			'.xml'    : 'text/xml',
			'.js'     : 'text/javascript',
			'.json'   : 'text/json',
			'.coffee' : "text/coffeescript",
			'.gif'    : 'image/gif',
			'.sketch' : 'application/octet-stream',
		}
		return extra_content_types[ext]

	def should_return_304(self):

		if self.is_text_content():
			return False

		return super(StaticFileHandler, self).should_return_304()

	def write_error(self, status_code, **kwargs):

		loader = tornado.template.Loader(os.path.join(self.application.static_path, "error"))

		if status_code == 404:
			self.finish(loader.load("404.html").generate())
			return

		return super(StaticFileHandler, self).write_error(status_code, **kwargs)

class APIHandler(tornado.web.RequestHandler):

	def get(self, command):
		command_name = "do_{0}".format(command)

		if hasattr(self, command_name):
			self.set_header("Content-Type", "application/json")

			try:
				self.finish(json_encode({"result": getattr(self, command_name)()}))
			except Exception, e:

				logging.error(traceback.format_exc())

				self.set_status(500)
				self.finish(json_encode({"error": e.message}))

		else:
			self.set_status(400)
			self.finish("404 Not found")

	def post(self, command):
		self._check_security() # Better safe then sorry
		self.get(command)

	def do_list(self):
		data = []

		for k, v in self.application._mounts.iteritems():
			data.append({
				"handle": v["handle"],
				"path": v["path"],
				"url": v["url"],
			})

		return data

	def do_mount(self):
		self._check_security()
		path = self._get_argument("path")
		path = os.path.abspath(path)

		if not os.path.exists(path):
			raise Exception("Path does not exist %s" % path)

		return self.application.mount(path)

	def do_unmount(self):
		self._check_security()
		path = self._get_argument("path")
		path = os.path.abspath(path)

		if not os.path.exists(path):
			raise Exception("Path does not exist %s" % path)

		self.application.unmount(path)

		return "OK"

	def do_eval(self):
		self._check_security()
		script = self._get_argument("script")
		self.application.eval(script)
		
		return "OK"

	def _get_argument(self, key, required=True):
		data = json_decode(self.request.body)

		if data.get(key, None) is None:
			raise Exception("Required key missing %s" % key)

		return data[key]

	def _check_security(self):
		# Only the machine this is running on is allowed
		if self.request.remote_ip not in ["127.0.0.1", self.application.local_ip]:
			raise HTTPError(403)


class ReloadApplication(tornado.web.Application):
	def __init__(self, port=8080):

		# self.path = path
		self.port = port
		self.static_path = os.path.join(os.path.dirname(__file__), "www")

		self.local_ip = get_local_ip_address()

		host = self.local_ip
		if not host: host = get_host_name()

		self._url = "http://{0}:{1}".format(host, self.port).lower()
		self._socket_handlers = []
		self._mounts = {}
    
		super(ReloadApplication, self).__init__([
			tornado.web.url(r"/_server/ws", WebSocketHandler),
			tornado.web.url(r"/_server/api/(.*)", APIHandler),
			tornado.web.url(r"/_server/(.*)", StaticFileHandler, {"path":self.static_path, "default_filename":"index.html"}),
			tornado.web.url(r"/", tornado.web.RedirectHandler, {"url": "/_server/app"}),
			tornado.web.url(r"/js/(.*)", StaticFileHandler, {"path":os.path.join(self.static_path, "js"), "default_filename":"index.html"}),
			tornado.web.url(r"/images/(.*)", StaticFileHandler, {"path":os.path.join(self.static_path, "images"), "default_filename":"index.html"}),
      tornado.web.url(r"/css/(.*)", StaticFileHandler, {"path":os.path.join(self.static_path, "css"), "default_filename":"index.html"}),
			tornado.web.url(r"/(.*)", StaticFileHandler, {"path":"", "default_filename":"index.html"}),
		], debug=True, serve_traceback=True, autoreload=False)

	@property
	def url(self):
		return self._url

	# Utility methods

	def _get_normalized_path(self, path):
		return os.path.abspath(path)

	def _get_name_for_path(self, path):
		# Todo: account for duplicate names
		return os.path.basename(path).replace(" ", "")

	# Server methods

	def start(self):
		self._server = tornado.httpserver.HTTPServer(self)
		self._server.listen(self.port)

		tornado.ioloop.IOLoop.instance().start()

	def stop(self):
		for handle, mount in self._mounts:
			self.unmount(mount["path"])

	# Mount and unmount

	def mount(self, path):
		path = self._get_normalized_path(path)
		name = self._get_name_for_path(path)
		rndm = random_string(6)
    
		if not os.path.exists(path):
			return logging.warning("reloader.mount: no such path: %s", path)

		self.add_handlers(r".*", [
			(r"/{0}/{1}/?(.*)".format(rndm, re.escape(name)), StaticFileHandler,
				{"path": path, "default_filename": "index.html"}, name),
		])

		mount = {
			"handle": name,
			"path": path,
			# "observer": observer,
			"url": "{0}/{1}/{2}/".format(self.url, rndm, name)
		}

		self._mounts[name] = mount

		return mount

	def unmount(self, path):		
		mount = self._get_mount_for_path(path)
		handle = mount["handle"]
		handler = self._get_handler_for_handle(handle)

		self.handlers.remove(handler)
		del self._mounts[handle]

	def _get_mount_for_path(self, path):
		for handle, m in self._mounts.iteritems():
			if m["path"] == path:
				return m

	def _get_handler_for_handle(self, handle):
		for handler in self.handlers:
			if handle == handler[1][0].name:
				return handler

	# Websocket methods

	def publish(self, message):
		for ws in self._socket_handlers:
			ws.write_message(message)

	def eval(self, script):
		self.publish({"command": "eval", "script": script})
